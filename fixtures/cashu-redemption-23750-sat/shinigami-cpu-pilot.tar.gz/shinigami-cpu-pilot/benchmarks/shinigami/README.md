# Shinigami CPU benchmark

This runs the fixed public testnet4 tapleaf case used to exercise Cashu Proofdesk's
Shinigami proof binding. It measures Cairo execution, Stwo proving, verification
with the independently pinned native verifier, and two tamper refusals. The
report records elapsed time, CPU time and peak RSS per stage, along with input
and output hashes. This Stwo executable uses CPU cores. A GPU's model does not
determine its speed. The Ark SP1/H100 checkpoint pilot uses a separate runtime
and measures a different workload.

Use the staged bundle on Linux x86-64 with Ubuntu 24.04 or equivalent glibc,
Python 3.11+, GNU time, and a CPU that supports the pinned Stwo executable.
Allow 64 GiB RAM and 10 GiB of free disk for the first unrestricted run. The
runner checks all native binaries and public inputs against `pins.json` before
starting. The bundle uses the already compiled executable and has no build or
package download step.

```sh
tar -xzf shinigami-cpu-pilot.tar.gz
cd shinigami-cpu-pilot
python3 benchmarks/shinigami/run.py "$PWD/pilot-output" --threads 8 --max-seconds 3300
```

To assemble the bundle from pinned files, run `python3 stage.py --help` from
this source directory. The packager includes the compiled public program and
public arguments. It never reads the local cache or a previous run directory.

Use a fresh output directory every time and compare only matching fixture and
profile hashes. Expect `fresh_proof_independently_verified` in `report.json` with
successful execution, proving and verification, and two normal exit-code-1
negative controls. Use `--execute-only` to validate the executable and runtime
without producing a STARK. Use `--audit-proof /absolute/proof.json` to verify an
existing proof without recording a new proving measurement. A failed or
interrupted run preserves the relevant log and completed measurements. The
timeout covers the entire workload, including verification.

The bundle contains a historical public testnet4 transaction vector. The report
attests to that computation and the exact script spend statement. The fixture
cannot be used as new funding. Keep generated trace and proof files private.
The report has the public statement, tool and proof hashes, and timings needed
for comparison.

## Fresh Cashu issuance

Run the existing isolated CDK/Core supervisor with the unpacked bundle:

```sh
python3 tests/run-regtest-stack.py --cdk /abs/cdk-mintd-0.18.3-x86_64 \
  --node /abs/node --shinigami-bundle /abs/shinigami-cpu-pilot
```

The wallet creates a real 25,000 sat regtest quote. Core funds and signs a
single-input Taproot spend into that quote. The test checks CDK's paid amount and
requires the desk to refuse admission while its Shinigami proof is absent. It
feeds the confirmed deposit to the pinned program, verifies the resulting
proof and its exact anchor and payment statement, and then retries admission
and exercises ordinary CDK issuance and wallet recovery. In full mode the
test keeps the same Core and mint alive until the wallet has checked the blind
signatures. It keeps the report in that run's private directory.

Use `--shinigami-execute-only` for a short CPU check that ends after Cairo
execution. This variant exercises a live paid quote and a missing-proof
refusal. Its run directory contains a case statement and argument file. To
benchmark that case independently, keep the matching `.json` and
`.args.json` together and add `--regtest-case /abs/shinigami-case.json` to the
benchmark command. The Core and CDK instances from the short test are gone by
then, so that benchmark alone cannot exercise issuance.

For cloud proving, start the supervisor with `--shinigami-external 3300`.
Once it prints `waiting_for_shinigami_proof`, copy the named case and argument
files to the ready cloud machine. Run the benchmark there with
`--regtest-case /abs/shinigami-case.json --max-seconds 3000`. When the remote
run verifies, copy its `verifier-input.json` to a temporary file alongside the
local `proof_target`, then rename it to that exact path. The original Core,
mint, and quote remain live during the wait. The desk independently verifies
the returned proof and its binding to Core before issuance. The wait expires
without issuance if no proof arrives.

The pinned exit-chain program requires the spending transaction's relative
locktime to impose no delay. A Cashu refusal claim protected by a nonzero
relative delay needs its own proof policy with authenticated heights.
