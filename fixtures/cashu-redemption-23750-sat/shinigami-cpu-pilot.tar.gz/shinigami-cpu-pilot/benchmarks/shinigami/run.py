"""Execute and independently audit one pinned, public Shinigami workload."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
from proofdesk.shinigami import FIELD_PRIME, PROOF_LIMIT, exit_statement, receipt_words
from proofdesk.verifier import read_bounded

TIME = "/usr/bin/time"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def compact(document):
    return json.dumps(document, separators=(",", ":")).encode()


def normalized_proof(path):
    raw = read_bounded(path, 64 * 1024 * 1024)
    document = json.loads(raw)
    if "extended_stark_proof" in document:
        if "stark_proof" in document:
            raise ValueError("ambiguous proof format")
        document["stark_proof"] = document.pop("extended_stark_proof")["proof"]
    if len(compact(document)) > PROOF_LIMIT:
        raise ValueError("normalized proof exceeds the Proofdesk size limit")
    return document


class Pilot:
    def __init__(self, directory, timeout, threads, pins, arguments, case_kind):
        self.directory = directory
        self.deadline = time.monotonic() + timeout
        self.pins = pins
        self.arguments = arguments
        self.redemption = case_kind == "fresh_cashu_redemption"
        self.env = os.environ.copy()
        for key in ("LD_PRELOAD", "LD_LIBRARY_PATH", "SCARB_MANIFEST_PATH", "SCARB_PROFILE",
                    "SCARB_PACKAGES_FILTER", "SCARB_LOG", "RAYON_RS_NUM_CPUS"):
            self.env.pop(key, None)
        self.env.update(PATH=f"{HERE / 'bin'}:/usr/bin:/bin", RAYON_NUM_THREADS=str(threads),
                        SCARB_TARGET_DIR=str(directory / "target"),
                        SCARB_CACHE=str(directory / "scarb-cache"), SCARB_OFFLINE="true",
                        NO_COLOR="1")
        self.report = {
            "schema": "proofdesk/shinigami-cpu-pilot/v1",
            "status": "started",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "backend": "cpu",
            "case": case_kind,
            "platform": platform.platform(),
            "cpu_model": next((line.partition(":")[2].strip() for line in
                               Path("/proc/cpuinfo").read_text().splitlines()
                               if line.startswith("model name")), None),
            "available_logical_cpus": len(os.sched_getaffinity(0)),
            "rayon_threads": threads,
            "time_limit_seconds": timeout,
            "source": pins["source"],
            "input_sha256": pins["sha256"],
            "phases": {},
        }

    def persist(self):
        temporary = self.directory / "report.tmp"
        temporary.write_text(json.dumps(self.report, indent=2) + "\n", encoding="utf-8")
        temporary.replace(self.directory / "report.json")

    def command(self, phase, argv, expected=0):
        metrics = self.directory / f"{phase}.time"
        log = self.directory / f"{phase}.log"
        start = time.monotonic()
        if start >= self.deadline:
            raise TimeoutError(f"pilot time limit reached before {phase}")
        self.report["status"] = phase
        self.persist()
        print(phase, flush=True)
        with log.open("xb") as output:
            with subprocess.Popen([TIME, "-q", "-f", "%M %U %S", "-o", metrics, *argv],
                                  cwd=self.directory, env=self.env, stdin=subprocess.DEVNULL,
                                  stdout=output, stderr=subprocess.STDOUT, start_new_session=True) as process:
                try:
                    code = process.wait(timeout=max(0.01, self.deadline - time.monotonic()))
                except BaseException:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGKILL)
                    raise
        result = {"exit_code": code, "elapsed_seconds": round(time.monotonic() - start, 3)}
        self.report["phases"][phase] = result
        if metrics.is_file():
            fields = metrics.read_text().strip().split()
            if len(fields) == 3:
                rss, user, system = fields
                result.update(peak_rss_kib=int(rss), user_cpu_seconds=float(user),
                              system_cpu_seconds=float(system))
        self.persist()
        if code != expected:
            raise RuntimeError(f"{phase} exited with {code}, expected {expected}. See {log.name}")
        return log.read_text(errors="replace")

    def execute(self):
        target = self.directory / "target"
        profile = target / "dev"
        profile.mkdir(parents=True)
        package = "vtxo_exit_proof"
        project = HERE
        manifest = project / "Scarb.toml"
        command = [HERE / "bin/scarb", "execute", "--no-build", "--output", "standard",
                   "--target", "bootloader", "--layout", "stwo_no_ecop",
                   "--arguments-file", self.arguments, "--print-resource-usage"]
        if self.redemption:
            project = HERE / "redemption"
            manifest = project / "Runtime.toml"
            package = "proofdesk_funded_redemption"
            command.append("--print-program-output")
        shutil.copyfile(manifest, self.directory / "Scarb.toml")
        shutil.copyfile(project / "main.executable.json", profile / "main.executable.json")
        output = self.command("execute", command)
        if self.redemption:
            from redemption.check import check_public_output

            self.report["public_words_matched"] = check_public_output(output, self.pins["statement"])
        traces = list((target / "execute" / package).glob("execution*/prover_input.json"))
        if len(traces) != 1 or not traces[0].is_file():
            raise RuntimeError("expected exactly one fresh Cairo prover input")
        return traces[0]

    def verify(self, proof):
        document = normalized_proof(proof)
        encoded = compact(document)
        if self.redemption:
            from redemption.check import PROGRAM_HASH

            statement = receipt_words(document, self.pins["bootloader_sha256"], PROGRAM_HASH)
        else:
            statement = exit_statement(encoded, self.pins["bootloader_sha256"])
        if statement != self.pins["statement"]:
            raise ValueError("proof public statement differs from the pinned fixture")
        candidate = self.directory / "verifier-input.json"
        candidate.write_bytes(encoded)
        verify = [HERE / "bin/scarb-verify", "--proof-file", candidate]
        if "Verified proof successfully" not in self.command("verify", verify):
            raise RuntimeError("the native verifier did not confirm acceptance")

        def require_rejection(name):
            candidate.write_bytes(compact(document))
            reply = self.command(name, verify, expected=1)
            if "verified proof successfully" in reply.lower() or "verification failed" not in reply.lower():
                raise RuntimeError(f"{name} did not report a normal verification failure")

        amount_position = 7 if self.redemption else 6
        leaf = document["claim"]["public_data"]["public_memory"]["output"][amount_position][1]
        leaf[0] ^= 1
        require_rejection("reject_changed_anchor_amount")
        leaf[0] ^= 1
        commitment = document["stark_proof"]["commitments"][0]
        commitment[0] ^= 1
        require_rejection("reject_changed_commitment")
        candidate.write_bytes(encoded)
        self.report.update(statement=statement, proof_sha256=digest(proof),
                           proof_bytes=proof.stat().st_size,
                           verifier_input_sha256=hashlib.sha256(encoded).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="A directory that does not exist yet")
    parser.add_argument("--threads", type=int, help="Rayon threads (default: up to eight available CPUs)")
    parser.add_argument("--max-seconds", type=int, default=3300)
    cases = parser.add_mutually_exclusive_group()
    cases.add_argument("--regtest-case", type=Path, help="Use a fresh case exported by the Cashu integration test")
    cases.add_argument("--redemption-case", type=Path, help="Use a case directory from redemption/case.py")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--execute-only", action="store_true")
    mode.add_argument("--audit-proof", type=Path, help="Audit an existing local proof without benchmarking")
    args = parser.parse_args()
    if platform.system() != "Linux" or platform.machine() != "x86_64" or not Path(TIME).is_file():
        parser.error("the pinned runtime requires x86-64 Linux and GNU time")
    cpus = len(os.sched_getaffinity(0))
    threads = min(8, cpus) if args.threads is None else args.threads
    if not 0 < threads <= cpus or args.max_seconds < 1:
        parser.error("threads must fit available CPUs and the time limit must be positive")
    pins = json.loads((HERE / "pins.json").read_text())
    for name, expected in pins["sha256"].items():
        if digest(HERE / name) != expected:
            raise ValueError(f"pinned asset failed SHA-256 verification ({name})")
    case_kind = "historical_testnet4"
    arguments = HERE / "testnet4-tapleaf-args.json"
    if args.regtest_case:
        case_path = args.regtest_case.resolve()
        case = json.loads(read_bounded(case_path, 16384))
        arguments = case_path.with_suffix(".args.json")
        if case["schema"] != "proofdesk/shinigami-regtest-case/v1" or digest(arguments) != case["arguments_sha256"]:
            raise ValueError("regtest case arguments failed the fixture hash check")
        case_kind = "fresh_cashu_regtest"
        pins["sha256"]["regtest_arguments"] = case["arguments_sha256"]
        pins["statement"] = case["statement"]
    if args.redemption_case:
        from redemption.check import PROGRAM_HASH

        program = HERE / "redemption"
        program_pins = json.loads((program / "pins.json").read_text())
        executable = program / "main.executable.json"
        executable_sha256 = digest(executable)
        if executable_sha256 != program_pins["executable_sha256"]:
            raise ValueError("redemption executable failed SHA-256 verification")
        case = args.redemption_case.resolve()
        arguments = case / "honest.args.json"
        words = json.loads(read_bounded(case / "statement.json", 4096))
        if not isinstance(words, list) or len(words) != 21:
            raise ValueError("invalid redemption statement length")
        statement = [int(word, 16) for word in words]
        if (statement[0] != int.from_bytes(b"PROOFDESK_CSV_REDEEM_V1", "big")
                or any(not 0 <= word < FIELD_PRIME for word in statement)):
            raise ValueError("invalid redemption statement")
        pins["statement"] = statement
        pins["source"] = {
            "shinigami_revision": pins["source"]["shinigami_revision"],
            "scarb_version": pins["source"]["scarb_version"],
            "program_hash": hex(PROGRAM_HASH),
        }
        pins["sha256"].update(redemption_executable=executable_sha256,
                              redemption_arguments=digest(arguments))
        case_kind = "fresh_cashu_redemption"

    directory = args.output.resolve()
    directory.mkdir(mode=0o700)
    pilot = Pilot(directory, args.max_seconds, threads, pins, arguments, case_kind)
    os.umask(0o077)
    pilot.persist()
    try:
        if args.audit_proof:
            pilot.verify(args.audit_proof.resolve())
            pilot.report["status"] = "existing_proof_audited"
        else:
            prover_input = pilot.execute()
            if args.execute_only:
                pilot.report["status"] = "fixture_executed"
            else:
                proof = directory / "proof.json"
                pilot.command("prove", [HERE / "bin/prove-clean", "--prover_input_path", prover_input,
                                         "--params_json", HERE / "profile.json", "--proof_path", proof])
                pilot.verify(proof)
                pilot.report["status"] = "fresh_proof_independently_verified"
    except BaseException as error:
        pilot.report.update(status="failed", error=str(error))
        raise
    finally:
        pilot.report["finished_at"] = datetime.now(timezone.utc).isoformat()
        pilot.persist()


if __name__ == "__main__":
    main()
