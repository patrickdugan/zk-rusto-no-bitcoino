"""Serialize the isolated Core payout fixture for the timed redemption program."""
import argparse
import hashlib
import json
from pathlib import Path


def cairo_bytes(data):
    full, tail = divmod(len(data), 31)
    words = [int.from_bytes(data[i * 31:(i + 1) * 31], "big") for i in range(full)]
    return [full, *words, int.from_bytes(data[31 * full:], "big"), tail]


def limbs(value):
    return [value % 2**128, value >> 128]


def wire_txid(value):
    raw = bytes.fromhex(value)
    if len(raw) != 32:
        raise ValueError("invalid txid")
    return int.from_bytes(raw, "little")


def prepare(state, report):
    if report["network"] != "regtest" or report["status"] != "confirmed_regtest_holder_reserve_redemption":
        raise ValueError("expected a confirmed regtest reserve payout")
    if state["reserve"] != report["reserve"] or state["claim_commitment"] != report["cashu_claim_commitment"]:
        raise ValueError("state belongs to a different claim")
    evidence = report["chain_evidence"]
    raw = bytes.fromhex(state["fallback_tx"])
    wtxid = hashlib.sha256(hashlib.sha256(raw).digest()).digest()[::-1].hex()
    if wtxid != evidence["spend_wtxid"]:
        raise ValueError("spend witness differs from Bitcoin Core's confirmed spend")
    if state["value_sat"] != evidence["reserve_amount_sat"] or state["funding_height"] != evidence["reserve_height"]:
        raise ValueError("reserve amount or height differs from Core")
    reserve = report["reserve"]
    tag = bytes.fromhex(report["cashu_claim_commitment"])
    if len(tag) != 32:
        raise ValueError("invalid claim tag")
    reserve_fields = [*limbs(wire_txid(reserve["txid"])), reserve["vout"], evidence["reserve_amount_sat"],
                      *cairo_bytes(bytes.fromhex(evidence["reserve_script"]))]
    destination = cairo_bytes(bytes.fromhex(evidence["payout_script"]))
    fields = [*reserve_fields, evidence["reserve_height"], evidence["spend_height"],
              *limbs(int.from_bytes(tag, "big")), *destination]
    payout = [report["payout_sat"], *limbs(wire_txid(report["confirmed_spend"])), *limbs(wire_txid(wtxid))]
    statement = [int.from_bytes(b"PROOFDESK_CSV_REDEEM_V1", "big"), *fields, *payout]

    premature = [*fields]
    premature[len(reserve_fields) + 1] = evidence["reserve_height"] + report["timeout_blocks"] - 1
    changed_amount = [*fields]
    changed_amount[3] -= 1
    transaction = cairo_bytes(raw)
    return {"honest.args.json": fields + transaction,
            "early.args.json": premature + transaction,
            "wrong_amount.args.json": changed_amount + transaction,
            "statement.json": statement}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("state", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("output", type=Path, help="A case directory that does not already exist")
    args = parser.parse_args()
    vectors = prepare(json.loads(args.state.read_text()), json.loads(args.report.read_text()))
    args.output.mkdir(mode=0o700)
    for name, values in vectors.items():
        (args.output / name).write_text(json.dumps([hex(value) for value in values]) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
